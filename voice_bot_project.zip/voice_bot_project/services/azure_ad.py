class AzureADService:
    async def set_user_password(self, user_id: str, new_password: str):
        print(f"[Azure AD] Password reset for {user_id} to: {new_password}")
        return True
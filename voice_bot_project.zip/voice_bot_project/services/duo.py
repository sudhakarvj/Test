import asyncio

class DuoService:
    async def send_push(self, user_id: str) -> bool:
        print(f"[Duo] Sending Push Notification to {user_id}...")
        # Simulate user approval delay
        await asyncio.sleep(3)
        print("[Duo] Push Approved.")
        return True

    async def check_enrollment(self, user_id: str) -> dict:
        print(f"[Duo] Checking status for {user_id}")
        return {"status": "active", "enrolled": True, "locked": False}

    async def send_activation_link(self, user_id: str):
        print(f"[Duo] Activation link sent to mobile for {user_id}")
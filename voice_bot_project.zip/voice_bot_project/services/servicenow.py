import os
import base64
import asyncio

class ServiceNowService:
    def __init__(self):
        self.base_url = os.getenv("SERVICENOW_URL")
        self.user = os.getenv("SERVICENOW_USER")
        self.pwd = os.getenv("SERVICENOW_PASS")

    async def validate_user(self, user_id: str) -> bool:
        print(f"[ServiceNow] Validating User ID: {user_id}")
        await asyncio.sleep(1) # Simulate API latency
        # Mock Logic: Accept any ID starting with 'U'
        if user_id and user_id.lower().startswith("u"):
            return True
        return False

    async def create_incident(self, caller_id, short_desc, work_notes) -> str:
        print(f"[ServiceNow] Creating Incident for {caller_id} | {short_desc}")
        # In real prod, use aiohttp.post here
        ticket_number = "INC" + str(id(work_notes))[:7]
        return ticket_number
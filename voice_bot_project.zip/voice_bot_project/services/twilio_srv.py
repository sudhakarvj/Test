import os

class TwilioService:
    async def transfer_to_human(self, ctx):
        print("[Twilio] Initiating Transfer...")
        # In LiveKit, you might use SIP header manipulation or a separate Twilio call
        await ctx.room.disconnect()
import secrets
import string

def generate_azure_password(length=12):
    """
    Generates a password meeting Azure AD complexity:
    - Upper, Lower, Digit, Special Char
    """
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
    while True:
        password = ''.join(secrets.choice(alphabet) for i in range(length))
        if (any(c.islower() for c in password)
                and any(c.isupper() for c in password)
                and any(c.isdigit() for c in password)
                and any(c in "!@#$%^&*" for c in password)):
            return password

def to_nato_phonetic(text):
    """
    Converts string to NATO phonetic script with pauses for slow reading.
    """
    nato_map = {
        'a': 'alpha', 'b': 'bravo', 'c': 'charlie', 'd': 'delta', 'e': 'echo', 
        'f': 'foxtrot', 'g': 'golf', 'h': 'hotel', 'i': 'india', 'j': 'juliett', 
        'k': 'kilo', 'l': 'lima', 'm': 'mike', 'n': 'november', 'o': 'oscar', 
        'p': 'papa', 'q': 'quebec', 'r': 'romeo', 's': 'sierra', 't': 'tango', 
        'u': 'uniform', 'v': 'victor', 'w': 'whiskey', 'x': 'x-ray', 'y': 'yankee', 
        'z': 'zulu',
        '0': 'zero', '1': 'one', '2': 'two', '3': 'three', '4': 'four', 
        '5': 'five', '6': 'six', '7': 'seven', '8': 'eight', '9': 'nine'
    }
    special_map = {
        '!': 'exclamation mark', '@': 'at symbol', '#': 'hash', 
        '$': 'dollar sign', '%': 'percent', '^': 'caret', 
        '&': 'ampersand', '*': 'asterisk'
    }

    script = []
    for char in text:
        lower_char = char.lower()
        if lower_char in nato_map:
            prefix = "Capital" if char.isupper() else "Small"
            if char.isdigit():
                 script.append(f"Number {nato_map[lower_char]}")
            else:
                 script.append(f"{prefix} {char}, as in {nato_map[lower_char]}")
        elif char in special_map:
            script.append(special_map[char])
        else:
            script.append(char)
            
    # Add pauses (...) for the Text-to-Speech engine
    return "... ... ".join(script)
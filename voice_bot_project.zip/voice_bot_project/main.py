import asyncio
import os
import logging
from dotenv import load_dotenv

from livekit.agents import AutoSubscribe, JobContext, WorkerOptions, cli, llm
# IMPORT AZURE PLUGINS
from livekit.plugins import openai, azure 

from agents.clara import ClaraAgent

load_dotenv()
logger = logging.getLogger("voice-bot")

async def entrypoint(ctx: JobContext):
    # 1. Connect
    await ctx.connect(auto_subscribe=AutoSubscribe.AUDIO_ONLY)

    # 2. Configure Azure Plugins
    # Azure STT (Speech to Text)
    stt = azure.STT(
        speech_key=os.getenv("AZURE_SPEECH_KEY"),
        speech_region=os.getenv("AZURE_SPEECH_REGION")
    )

    # Azure TTS (Text to Speech)
    tts = azure.TTS(
        speech_key=os.getenv("AZURE_SPEECH_KEY"),
        speech_region=os.getenv("AZURE_SPEECH_REGION"),
        voice="en-US-AvaMultilingualNeural" # You can pick specific Azure voices
    )

    # Azure OpenAI LLM
    # The plugin automatically detects Azure env vars, but we pass the model/deployment explicitly
    model = openai.LLM.with_azure(
        model=os.getenv("AZURE_OPENAI_DEPLOYMENT"),
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION")
    )

    # 3. Initialize Context
    participant = await ctx.wait_for_participant()
    
    user_session = {
        "user_id": None,
        "language": "en",
        "participant": participant,
        "room": ctx.room,
        # Pass the Azure models to your agents so they use them!
        "stt": stt,
        "tts": tts,
        "llm": model
    }

    # 4. Start Clara
    clara = ClaraAgent(ctx, user_session)
    await clara.run()

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    cli.run_app(WorkerOptions(entrypoint_fnc=entrypoint))
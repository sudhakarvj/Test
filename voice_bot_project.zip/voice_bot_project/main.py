import asyncio
import os
import logging
from dotenv import load_dotenv
from livekit.agents import AutoSubscribe, JobContext, WorkerOptions, cli, llm
from livekit.plugins import openai, deepgram

# Import the Orchestrator
from agents.clara import ClaraAgent

load_dotenv()
logger = logging.getLogger("voice-bot")

async def entrypoint(ctx: JobContext):
    # Connect to the room (Audio Only)
    await ctx.connect(auto_subscribe=AutoSubscribe.AUDIO_ONLY)

    # Participant identity (User)
    participant = await ctx.wait_for_participant()
    
    # Initialize shared session state
    # This dictionary is passed between agents (Clara -> Zen/Zeno/Zara)
    user_session = {
        "user_id": None,
        "language": "en",  # Default English
        "participant": participant,
        "room": ctx.room
    }

    # Start the Orchestrator (Clara)
    clara = ClaraAgent(ctx, user_session)
    await clara.run()

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    cli.run_app(WorkerOptions(entrypoint_fnc=entrypoint))
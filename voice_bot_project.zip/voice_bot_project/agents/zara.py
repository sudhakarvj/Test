from .base_agent import BaseAgent
from .zen import ZenAgent
from .zeno import ZenoAgent

class ZaraAgent(BaseAgent):
    async def run(self):
        self.log("Started VPN Troubleshooting")
        
        # Logic Step 1
        await self.context.say("Ensure you are connected to Wifi. Open Cisco VPN. URL is remote.zensar.com.")
        
        # Logic Step 2 (Diagnostic)
        await self.context.say("Are you facing a password issue or a Duo push issue?")
        
        # Assume we detected 'password' via STT
        detected_issue = "password" 

        if detected_issue == "password":
            await self.context.say("Transferring you to Zen for password reset.")
            await ZenAgent(self.context, self.user_session).run()
        elif detected_issue == "duo":
            await self.context.say("Transferring you to Zeno for Duo issues.")
            await ZenoAgent(self.context, self.user_session).run()
        else:
            ticket = await self.create_ticket_and_end("VPN General Inquiry")
            await self.context.say("Ticket created.")
from .base_agent import BaseAgent
from .zen import ZenAgent
from .zeno import ZenoAgent
from .zara import ZaraAgent

class ClaraAgent(BaseAgent):
    async def run(self):
        # 1. Greeting
        await self.context.say("Hi, I'm Clara, your voice assistant.")
        
        # 2. Language Selection
        # Simple simulation
        await self.context.say("Do you wish to continue in English or French?")
        res = await self.context.wait_for_user_speech() # Pseudo-code for STT
        # Assume English for this demo
        self.user_session['language'] = 'en'
        self.log("Language: English")

        # 3. User Validation
        valid = False
        while not valid:
            await self.context.say("Please provide your User ID.")
            # In real code: capture speech, extract ID
            # Simulating user input for the demo:
            user_input_id = "U12345" 
            
            valid = await self.sn_service.validate_user(user_input_id)
            if valid:
                self.user_session['user_id'] = user_input_id
                await self.context.say("Thank you. ID verified.")
            else:
                await self.context.say("ID not found. Let's try again.")

        # 4. Intent Routing
        await self.context.say("How can I help? Password reset, Duo enrollment, or Cisco VPN issue?")
        
        # Wait for actual user voice input
        # Note: In LiveKit Agents, we usually use an LLM to classify intent here.
        # For simplicity, we assume we extract keywords.
        # Let's assume the user says "Password reset"
        
        # NOTE: To make this runnable without a real microphone, you'd wire the LLM here.
        # Below is the logic flow:
        
        user_intent = "password" # This would come from STT

        if "password" in user_intent:
            await ZenAgent(self.context, self.user_session).run()
        elif "duo" in user_intent:
            await ZenoAgent(self.context, self.user_session).run()
        elif "vpn" in user_intent:
            await ZaraAgent(self.context, self.user_session).run()
        elif "human" in user_intent:
            await self.transfer_call()
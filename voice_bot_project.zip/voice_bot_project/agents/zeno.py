from .base_agent import BaseAgent
from services.duo import DuoService

class ZenoAgent(BaseAgent):
    async def run(self):
        self.log("Started Duo Enrollment Flow")
        duo = DuoService()
        status = await duo.check_enrollment(self.user_session['user_id'])

        if status['locked'] or status['enrolled']:
            await self.context.say("Account exists. Sending activation link and push notification.")
            await duo.send_activation_link(self.user_session['user_id'])
            await duo.send_push(self.user_session['user_id'])
        else:
            await self.context.say("Please enroll via the self-service portal.")

        ticket = await self.create_ticket_and_end("Duo Enrollment Query")
        await self.context.say(f"Ticket {ticket} created. Goodbye.")
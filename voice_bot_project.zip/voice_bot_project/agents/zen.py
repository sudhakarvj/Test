from .base_agent import BaseAgent
from services.duo import DuoService
from services.azure_ad import AzureADService
from utils.security_utils import generate_azure_password, to_nato_phonetic

class ZenAgent(BaseAgent):
    async def run(self):
        self.log("Started Password Reset Flow")
        duo = DuoService()
        azure = AzureADService()

        # 1. Duo Push
        await self.context.say("Sending Duo push for approval.")
        approved = await duo.send_push(self.user_session['user_id'])
        
        if not approved:
            await self.context.say("Approval failed.")
            await self.transfer_call()
            return

        # 2. Generate Password
        new_pass = generate_azure_password()
        await azure.set_user_password(self.user_session['user_id'], new_pass)
        nato_script = to_nato_phonetic(new_pass)
        
        # 3. Dictation Loop
        await self.context.say("Identity verified. I created a temporary password.")
        
        # Spell out normally first
        spelled = ", ".join(list(new_pass))
        await self.context.say(f"It is: {spelled}")

        # Loop for repetition
        while True:
            # wait_for_user_speech is a placeholder for the actual LLM/STT event listener
            await self.context.say("Did you get that? Or say 'repeat' to hear it slowly.")
            
            # SIMULATION of User Input logic
            # In production, use: text = await self.context.wait_for_input()
            # If text == 'repeat': ...
            
            # For this code structure, we break to finish
            break 
            
            # LOGIC FOR REPEAT:
            # await self.context.say("Repeating slowly.")
            # await self.context.say(nato_script)

        # 4. Ticket
        ticket = await self.create_ticket_and_end("Password Reset Success")
        await self.context.say(f"Ticket {ticket} created. Goodbye.")
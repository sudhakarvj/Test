from services.servicenow import ServiceNowService
from services.twilio_srv import TwilioService

class BaseAgent:
    def __init__(self, context, user_session):
        self.context = context
        self.user_session = user_session
        self.sn_service = ServiceNowService()
        self.twilio_service = TwilioService()
        self.chat_history = []

    def log(self, text):
        self.chat_history.append(text)

    async def transfer_call(self):
        await self.context.say("Transferring you to a human agent now. Please hold.")
        await self.twilio_service.transfer_to_human(self.context)

    async def create_ticket_and_end(self, description):
        transcript = "\n".join(self.chat_history)
        ticket = await self.sn_service.create_incident(
            caller_id=self.user_session.get('user_id', 'Unknown'),
            short_description=description,
            work_notes=f"TRANSCRIPT:\n{transcript}"
        )
        return ticket